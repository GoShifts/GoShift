const environment = {
  PORT: 8000,
  // PORT: 27017,
  // MONGO_URI: `mongodb+srv://root:root@nodeexpressprojects.fdhlpba.mongodb.net/?retryWrites=true&w=majority&dbname=goshift`,
  MONGO_URI: `mongodb://goshift:2Te5zjmBRJ7GXayY@203.161.52.248:27017/godb`,
  SECRET_KEY: `fluffy`,
  // BASE_URL: `http://localhost:3000/`,
  BASE_URL: `https://avoda.ai/`,
  HOST: `smtp.gmail.com`,
  SERVICE: `gmail`,
  EMAIL_PORT: 587,
  SECURE: true,
  USER: `demofornode09@gmail.com`,
  PASS: `Node1122`,
};

export default environment;
